export const baseUrl = "https://xhouse.in.ua/sel/API_V2";
