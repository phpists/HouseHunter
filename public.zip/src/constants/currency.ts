export const currencies = [
  { symbol: "₴", title: "UAH" },
  { symbol: "$", title: "USD" },
  { symbol: "€", title: "EUR" },
];
