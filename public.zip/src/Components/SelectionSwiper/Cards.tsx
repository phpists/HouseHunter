import { styled } from "styled-components";
import { Card } from "./Card/Card";
import { Empty } from "../Swaper/Empty";
import { Animation } from "./Animation";
import { getLocation } from "../../helpers";

interface Props {
  cards: any[];
  history?: boolean;
  cardStatusChanged: null | string;
  onShowPhotos: (photos: string[]) => void;
  onChangeStatus: (
    index: number,
    direction: string | null,
    id: string,
    type: string
  ) => void;
  onSendRealtor: (type: string, id: string) => void;
  currency: string;
  onChangeCurrency: (value: string) => void;
}

export const Cards = ({
  cards,
  history,
  cardStatusChanged,
  onShowPhotos,
  onChangeStatus,
  onSendRealtor,
  currency,
  onChangeCurrency,
}: Props) => (
  <StyledCards
    className="flex items-center justify-center"
    isEmpty={cards.length === 0}
  >
    {cardStatusChanged && history && <Animation status={cardStatusChanged} />}
    {cards.length > 0 ? (
      cards.map((card, i) => (
        <Card
          key={i}
          type={card?.rubric_name ?? ""}
          currency={currency}
          onChangeCurrency={onChangeCurrency}
          price={card?.price ? card?.price[currency] : 0}
          location={getLocation(card?.location)}
          doors={"-"}
          area={"-"}
          stairs="- із -"
          box="-"
          title={card?.title ?? ""}
          description={card?.description ?? ""}
          index={1 + i}
          images={card?.image_url ?? []}
          onShowPhotos={() => onShowPhotos([])}
          onChangeStatus={(direction) =>
            onChangeStatus(i, direction, card?.id_object, card?.type)
          }
          history={history}
          totalCards={cards?.length ?? 0}
          onSendRealtor={() => onSendRealtor(card?.type, card?.id_object)}
        />
      ))
    ) : (
      <Empty />
    )}
  </StyledCards>
);

interface StyledCardsProps {
  isEmpty: boolean;
}

const StyledCards = styled.div<StyledCardsProps>`
  height: calc(100vh - 280px);
  width: 100%;
  margin-bottom: 15px;
  border-radius: 13px;
  position: relative;
  overflow: unset;
  transition: all 0.3s;
  overflow-x: hidden;
  ${({ isEmpty }) =>
    isEmpty &&
    `
  border: 1px dashed rgba(255, 255, 255, 0.3);
  background: rgba(0, 0, 0, 0.3);
  `}
  ::-webkit-scrollbar {
    display: none;
  }
`;
