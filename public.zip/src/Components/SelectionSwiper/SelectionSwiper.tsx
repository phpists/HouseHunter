import { styled } from "styled-components";
import { Footer } from "./Footer/Footer";
import { Cards } from "./Cards";
import { useState } from "react";

interface Props {
  cards: any[];
  onSwap: (index: number, direction: string, id: string, type: string) => void;
  history?: boolean;
  onSendRealtor: (type: string, id: string) => void;
  currency: string;
  onChangeCurrency: (value: string) => void;
  disabled?: boolean;
}

export const SelectionSwiper = ({
  cards,
  onSwap,
  history,
  onSendRealtor,
  currency,
  onChangeCurrency,
  disabled,
}: Props) => {
  const [cardStatusChanged, setCardStatusChanged] = useState<null | string>(
    null
  );
  const [showPhotos, setShowPhotos] = useState<boolean>(false);
  const [photos, setPhotos] = useState<string[]>([]);

  const handleChangeCardStatus = (
    index: number,
    value: string | null,
    id: string,
    type: string
  ) => {
    if (!cardStatusChanged) {
      history && setCardStatusChanged(value);
      if (value) {
        if (history) {
          onSwap(index, value, id, type);
          setTimeout(() => {
            setCardStatusChanged(null);
          }, 3000);
        } else {
          onSwap(index, value, id, type);
        }
      }
    }
  };

  const handleShowPhotos = (photos: string[]) => {
    setShowPhotos(true);
    setPhotos(photos);
  };

  const handleSendRealtor = () => {
    if (cards.length > 0) {
      const type = cards[cards.length - 1]?.type ?? "";
      const id = cards[cards.length - 1]?.id_object ?? "";

      onSendRealtor(type, id);
    }
  };

  const handleChangeStatusFooter = (direction: string | null) => {
    if (cards.length > 0) {
      const type = cards[cards.length - 1]?.type ?? "";
      const id = cards[cards.length - 1]?.id_object ?? "";

      handleChangeCardStatus(cards.length - 1, direction, id, type);
    }
  };

  return (
    <StyledSelectionSwiper className="flex flex-col justify-between">
      {/* <Photos
        open={showPhotos}
        onClose={() => setShowPhotos(false)}
        images={photos}
      /> */}
      <Cards
        cards={cards}
        history={history}
        cardStatusChanged={cardStatusChanged}
        onShowPhotos={handleShowPhotos}
        onChangeStatus={handleChangeCardStatus}
        onSendRealtor={onSendRealtor}
        currency={currency}
        onChangeCurrency={onChangeCurrency}
      />
      <Footer
        onChangeStatus={handleChangeStatusFooter}
        onSendRealtor={handleSendRealtor}
        disabled={disabled}
      />
    </StyledSelectionSwiper>
  );
};

const StyledSelectionSwiper = styled.div`
  padding: 15px 0;
  @media (min-width: 1000px) {
    display: none;
  }
`;
