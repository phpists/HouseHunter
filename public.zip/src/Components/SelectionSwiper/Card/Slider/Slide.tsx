import { styled } from "styled-components";
import { useRef } from "react";
interface Props {
  image: string;
  onClick: () => void;
}

export const Slide = ({ image, onClick }: Props) => {
  const isDobleTap = useRef(false);

  const handleDetectDobleTouch = () => {
    if (!isDobleTap.current) {
      isDobleTap.current = true;
      setTimeout(function () {
        isDobleTap.current = false;
      }, 300);
      return false;
    } else {
      onClick();
    }
  };

  return (
    <StyledSlide
      image={image}
      onDoubleClick={onClick}
      onTouchEnd={handleDetectDobleTouch}
      className="clickable"
    />
  );
};

interface StyledSlideProps {
  image: string;
}

const StyledSlide = styled.div<StyledSlideProps>`
  transition: all 0.3s;
  background: url(${({ image }) => image}) center/cover no-repeat;
  height: calc(100vh - 310px);
`;
