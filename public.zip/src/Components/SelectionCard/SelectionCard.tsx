import { styled } from "styled-components";
import { Banner } from "./Banner/Banner";
import { Info } from "./Info/Info";

interface Props {
  onOpen: () => void;
  isNew?: boolean;
  onSendRealtor?: () => void;
  area: string | number;
  currency: string;
  price: number;
  title: string;
  location: string;
  doors: number | string;
  stairs: string;
  description?: string;
  images: string[];
  onSwap?: (direction: string) => void;
}

export const SelectionCard = ({
  onOpen,
  isNew,
  onSendRealtor,
  area,
  currency,
  price,
  title,
  location,
  doors,
  stairs,
  description,
  images,
  onSwap,
}: Props) => {
  return (
    <StyledSelectionCard>
      <Banner
        onOpen={onOpen}
        isNew={isNew}
        currency={currency}
        price={price}
        area={area}
        images={images}
      />
      <Info
        onOpen={onOpen}
        isNew={isNew}
        onSendRealtor={onSendRealtor}
        title={title}
        location={location}
        currency={currency}
        price={price}
        doors={doors}
        stairs={stairs}
        description={description}
        onSwap={onSwap}
      />
    </StyledSelectionCard>
  );
};

const StyledSelectionCard = styled.div`
  width: 100%;
  cursor: pointer;
`;
