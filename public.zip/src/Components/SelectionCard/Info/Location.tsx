import locationIcon from "../../../assets/images/location-2.svg";

interface Props {
  location: string;
}

export const Location = ({ location }: Props) => (
  <div className="flex items-center">
    <img src={locationIcon} alt="" className="mr-2 mb-2" />
    {location}
  </div>
);
