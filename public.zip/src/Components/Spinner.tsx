import { styled } from "styled-components";
import spinner from "../assets/images/spinner.svg";

interface Props {
  className?: string;
}

export const Spinner = ({ className }: Props) => (
  <StyledSpinner className={`${className}`}>
    <img src={spinner} alt="" />
  </StyledSpinner>
);

const StyledSpinner = styled.div`
  img {
    height: 40px;
  }
`;
