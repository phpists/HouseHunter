import { SelectionSwiper } from "../../Components/SelectionSwiper/SelectionSwiper";
import { NewSelectionDesktop } from "./NewSelectionDesktop/NewSelectionDesktop";
import { useEffect, useState, useRef } from "react";
import { getNewSelections, rate } from "../../api/methods";
import { Spinner } from "../../Components/Spinner";

interface Props {
  onOpenInfo: (card: any) => void;
  onSendRealtor: (type: string, id: string) => void;
  currency: string;
  onChangeCurrency: (value: string) => void;
}

export const NewSelections = ({
  onOpenInfo,
  onSendRealtor,
  currency,
  onChangeCurrency,
}: Props) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [cards, setCards] = useState<any[]>([]);
  const cardsData = useRef<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const isFirstRender = useRef(true);

  const handleGetSelections = (perPage?: number) => {
    console.log("here");
    setLoading(true);
    getNewSelections(currentPage, perPage).then((resp: any) => {
      const data = resp?.data?.data;
      setLoading(false);
      if (data) {
        cardsData.current = [...cardsData.current, ...data];
        setCards(cardsData.current);
      }
    });
  };

  const handleSwap = (
    index: number,
    direction: string,
    id: string,
    type: string
  ) => {
    const updatedCards = [...cardsData.current].filter(
      (card, i) => card.id_object !== id
    );
    setCards(updatedCards);
    cardsData.current = updatedCards;
    rate(direction === "right" ? 1 : 0, id, type).then(() => {
      if (updatedCards.length <= 10) {
        handleGetSelections(10);
      }
    });
  };

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      handleGetSelections(20);
    }
  }, []);

  return (
    <>
      {loading ? (
        <Spinner className="empty-title" />
      ) : (
        <>
          <NewSelectionDesktop
            cards={cards}
            onOpenInfo={onOpenInfo}
            onSendRealtor={onSendRealtor}
            currency={currency}
            onSwap={handleSwap}
          />
          <SelectionSwiper
            cards={[...cards].reverse()}
            onSwap={handleSwap}
            onSendRealtor={onSendRealtor}
            currency={currency}
            onChangeCurrency={onChangeCurrency}
            disabled={loading}
          />
        </>
      )}
    </>
  );
};
