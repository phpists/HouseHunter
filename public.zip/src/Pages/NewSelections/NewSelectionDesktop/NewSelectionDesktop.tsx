import { styled } from "styled-components";
import { SelectionCard } from "../../../Components/SelectionCard/SelectionCard";
import { getLocation } from "../../../helpers";
import { Empty } from "./Empty";

interface Props {
  cards: any;
  onOpenInfo: (card: any) => void;
  onSendRealtor: (type: string, id: string) => void;
  currency: string;
  onSwap: (index: number, direction: string, id: string, type: string) => void;
}

export const NewSelectionDesktop = ({
  cards,
  onOpenInfo,
  onSendRealtor,
  currency,
  onSwap,
}: Props) => (
  <StyledNewSelectionDesktop>
    {cards?.length > 0 ? (
      cards.map((card: any, i: number) => (
        <SelectionCard
          key={i}
          onOpen={() => onOpenInfo(card)}
          isNew
          onSendRealtor={() => onSendRealtor(card?.type, card?.id_object)}
          area={"-"}
          currency={currency}
          price={card?.price ? card?.price[currency] : 0}
          title={card?.title ?? ""}
          location={getLocation(card?.location)}
          doors={"-"}
          stairs="- із -"
          description={card?.description ?? ""}
          images={card?.image_url ?? []}
          onSwap={(direction) =>
            onSwap(i, direction, card?.id_object, card?.type)
          }
        />
      ))
    ) : (
      <Empty />
    )}
  </StyledNewSelectionDesktop>
);

const StyledNewSelectionDesktop = styled.div`
  display: grid;
  grid-template-columns: repeat(4, calc((98% - (24px * 2)) / 4));
  gap: 24px;
  grid-auto-rows: max-content;
  justify-content: center;
  margin: 50px 0;
  @media (max-width: 1000px) {
    display: none;
  }
  @media (max-width: 1200px) {
    grid-template-columns: repeat(3, calc((98% - (24px * 2)) / 3));
  }
`;
